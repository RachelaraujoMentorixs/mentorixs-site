/* Mentorixs — comportamento do site (sem dependências). */
(function () {
  'use strict';
  var doc = document.documentElement;
  doc.classList.remove('no-js');
  doc.classList.add('js');
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function storeSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* armazenamento indisponível */ } }

  /* ---------- Idioma: preferência + preservar estado da página ---------- */
  storeSet('mx-lang', doc.lang.indexOf('pt') === 0 ? 'pt' : 'en');
  document.querySelectorAll('[data-lang-link]').forEach(function (a) {
    if (!a.classList.contains('is-current') && (location.search || location.hash)) {
      a.href = a.href.split('#')[0].split('?')[0] + location.search + location.hash;
    }
    a.addEventListener('click', function () { storeSet('mx-lang', a.getAttribute('data-lang-link')); });
  });

  /* ---------- Cabeçalho ---------- */
  var header = document.querySelector('[data-header]');
  if (header) {
    var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Menu mobile ---------- */
  var toggle = document.querySelector('[data-menu-toggle]');
  var menu = document.querySelector('[data-menu]');
  if (toggle && menu) {
    var label = toggle.querySelector('[data-menu-label]');
    var setOpen = function (open, restoreFocus) {
      toggle.setAttribute('aria-expanded', String(open));
      menu.hidden = !open;
      document.body.classList.toggle('menu-open', open);
      label.textContent = toggle.getAttribute(open ? 'data-label-close' : 'data-label-open');
      if (open) {
        var first = menu.querySelector('a, button');
        if (first) first.focus();
      } else if (restoreFocus) {
        toggle.focus();
      }
    };
    toggle.addEventListener('click', function () { setOpen(toggle.getAttribute('aria-expanded') !== 'true', true); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) setOpen(false, false); });
    document.addEventListener('keydown', function (e) {
      if (menu.hidden) return;
      if (e.key === 'Escape') { setOpen(false, true); return; }
      if (e.key === 'Tab') {
        var items = [toggle].concat(Array.prototype.slice.call(menu.querySelectorAll('a, button')));
        var i = items.indexOf(document.activeElement);
        if (e.shiftKey && i <= 0) { e.preventDefault(); items[items.length - 1].focus(); }
        else if (!e.shiftKey && i === items.length - 1) { e.preventDefault(); items[0].focus(); }
      }
    });
    window.matchMedia('(min-width: 1140px)').addEventListener('change', function (m) { if (m.matches) setOpen(false, false); });
  }

  /* ---------- Animação de entrada (respeita movimento reduzido) ---------- */
  var revealEls = document.querySelectorAll('[data-reveal]');
  if (!reduceMotion && 'IntersectionObserver' in window && revealEls.length) {
    // Ordem dentro de cada grupo (cards de uma mesma grade entram em sequência).
    revealEls.forEach(function (el) {
      var siblings = Array.prototype.filter.call(el.parentElement.children, function (c) { return c.hasAttribute('data-reveal'); });
      var i = siblings.indexOf(el);
      if (i > 0) el.style.setProperty('--i', String(Math.min(i, 8)));
    });
    var show = function (el) {
      el.classList.add('is-visible');
      // Depois da entrada, remove o atraso para que o hover responda na hora.
      setTimeout(function () { el.style.removeProperty('--i'); }, 1400);
    };
    var vh = window.innerHeight;
    revealEls.forEach(function (el) { if (el.getBoundingClientRect().top < vh * 0.92) show(el); });
    doc.classList.add('reveal-ready');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { show(en.target); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    revealEls.forEach(function (el) { if (!el.classList.contains('is-visible')) io.observe(el); });
  }

  /* ---------- Demonstração: pausa as animações quando sai da tela ---------- */
  var concept = document.querySelector('.concept');
  if (concept && !reduceMotion && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { concept.classList.toggle('is-paused', !en.isIntersecting); });
    }).observe(concept);
    document.addEventListener('visibilitychange', function () { concept.classList.toggle('is-paused', document.hidden); });
  }

  /* ---------- Formulários ---------- */
  var i18nEl = document.getElementById('mx-i18n');
  var T = i18nEl ? JSON.parse(i18nEl.textContent) : null;
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function fmt(s, n) { return String(s).replace('{n}', n); }

  function fieldMessage(el) {
    var v = (el.value || '').trim();
    var V = T.validation;
    if (el.required && !v) return el.tagName === 'SELECT' ? V.select : V.required;
    if (!v) return '';
    if (el.type === 'email' && !EMAIL_RE.test(v)) return V.email;
    if (el.type === 'tel') {
      var digits = v.replace(/\D/g, '');
      if (digits.length < 8 || digits.length > 15 || /[^\d\s()+.\-]/.test(v)) return V.phone;
    }
    var min = parseInt(el.getAttribute('data-minlength') || '0', 10);
    if (min && v.length < min) return fmt(V.minLength, min);
    var max = parseInt(el.getAttribute('maxlength') || '0', 10);
    if (max && v.length > max) return fmt(V.maxLength, max);
    return '';
  }

  function showFieldError(form, el, msg) {
    var err = form.querySelector('[data-error-for="' + el.name + '"]');
    if (!err) return;
    if (msg) {
      err.textContent = msg; err.hidden = false; el.setAttribute('aria-invalid', 'true');
    } else {
      err.textContent = ''; err.hidden = true; el.removeAttribute('aria-invalid');
    }
  }

  function validatableFields(form) {
    return Array.prototype.filter.call(form.querySelectorAll('input.input, select.input, textarea.input'), function (el) {
      return !el.closest('[hidden]');
    });
  }

  function validate(form) {
    var invalid = [];
    validatableFields(form).forEach(function (el) {
      var msg = fieldMessage(el);
      showFieldError(form, el, msg);
      if (msg) invalid.push(el);
    });
    return invalid;
  }

  function serialize(form) {
    var data = {};
    var fd = new FormData(form);
    fd.forEach(function (value, key) {
      if (key === 'users') { (data.users = data.users || []).push(value); return; }
      data[key] = typeof value === 'string' ? value.trim() : value;
    });
    return data;
  }

  function initForm(form) {
    var endpoint = form.getAttribute('data-endpoint');
    var body = form.querySelector('[data-form-body]');
    var summary = form.querySelector('[data-form-summary]');
    var errorBox = form.querySelector('[data-form-error]');
    var errorText = form.querySelector('[data-form-error-text]');
    var success = form.querySelector('[data-form-success]');
    var submitBtn = form.querySelector('[data-submit]');
    var submitLabel = form.querySelector('[data-submit-label]');
    var started = form.querySelector('[data-started-at]');
    var attempted = false;
    var busy = false;

    var resetStart = function () { if (started) started.value = String(Date.now()); };
    resetStart();

    // Campo "Produto de interesse": visível apenas para "Sistema por assinatura" ou quando já vem preenchido pela URL.
    var interest = form.querySelector('select[name="interest"]');
    var productWrap = form.querySelector('[data-product-field]');
    var productSel = productWrap ? productWrap.querySelector('select') : null;
    var syncProduct = function () {
      if (!productWrap) return;
      var show = interest.value === 'subscription' || (productSel.value && productSel.value !== '');
      productWrap.hidden = !show;
    };
    if (interest && productWrap) {
      var params = new URLSearchParams(location.search);
      var qi = params.get('interest');
      var qp = params.get('product');
      if (qi && interest.querySelector('option[value="' + CSS.escape(qi) + '"]')) interest.value = qi;
      if (qp && productSel.querySelector('option[value="' + CSS.escape(qp) + '"]')) productSel.value = qp;
      interest.addEventListener('change', function () {
        if (interest.value !== 'subscription') productSel.value = '';
        syncProduct();
      });
      syncProduct();
    }

    form.addEventListener('input', function (e) {
      if (attempted && e.target.classList && e.target.classList.contains('input')) showFieldError(form, e.target, fieldMessage(e.target));
    });
    form.addEventListener('focusout', function (e) {
      var el = e.target;
      if (el.classList && el.classList.contains('input') && (attempted || el.value)) showFieldError(form, el, fieldMessage(el));
    });

    var setBusy = function (state) {
      busy = state;
      form.setAttribute('aria-busy', String(state));
      submitBtn.disabled = state;
      submitLabel.textContent = submitLabel.getAttribute(state ? 'data-label-busy' : 'data-label-idle');
    };

    var showError = function (msg) {
      errorText.textContent = msg + (T.errorAlt ? ' ' + T.errorAlt : '');
      errorBox.hidden = false;
      errorBox.focus();
    };

    var resetTurnstile = function () {
      if (window.turnstile && form.querySelector('.cf-turnstile')) { try { window.turnstile.reset(form.querySelector('.cf-turnstile')); } catch (e) {} }
    };

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (busy) return;
      attempted = true;
      errorBox.hidden = true;
      var invalid = validate(form);
      if (invalid.length) {
        summary.textContent = invalid.length === 1 ? T.errorSummaryOne : fmt(T.errorSummaryMany, invalid.length);
        summary.hidden = false;
        invalid[0].focus();
        return;
      }
      summary.hidden = true;

      var data = serialize(form);
      if (form.querySelector('.cf-turnstile') && !data['cf-turnstile-response']) { showError(T.errorCaptcha); return; }
      if (!endpoint) {
        if (window.console) console.warn('[Mentorixs] Formulário sem endpoint configurado (content/site.json → forms.endpoint).');
        showError(T.errorUnavailable);
        return;
      }

      setBusy(true);
      var controller = 'AbortController' in window ? new AbortController() : null;
      var timer = controller ? setTimeout(function () { controller.abort(); }, 20000) : null;

      fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(data),
        signal: controller ? controller.signal : undefined,
        credentials: 'same-origin'
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (json) { return { res: res, json: json }; });
      }).then(function (r) {
        // A confirmação só aparece quando o servidor informa que a solicitação foi recebida.
        if (r.res.ok && r.json && r.json.ok === true) {
          body.hidden = true;
          success.hidden = false;
          success.focus();
          return;
        }
        var err = r.json && r.json.error;
        if (err === 'validation' && r.json.fields) {
          var first = null;
          var count = 0;
          Object.keys(r.json.fields).forEach(function (name) {
            var info = r.json.fields[name] || {};
            var el = form.querySelector('[name="' + name + '"].input');
            var msg = T.validation[info.code] ? fmt(T.validation[info.code], info.n || '') : T.validation.required;
            if (el) { showFieldError(form, el, msg); first = first || el; count++; }
          });
          if (!count) { showError(T.errorGeneric); return; }
          summary.textContent = count === 1 ? T.errorSummaryOne : fmt(T.errorSummaryMany, count);
          summary.hidden = false;
          if (first) first.focus();
        } else if (err === 'spam') {
          showError(T.errorSpam);
        } else if (err === 'captcha') {
          showError(T.errorCaptcha);
        } else if (err === 'unavailable' || r.res.status === 503 || r.res.status === 404) {
          showError(T.errorUnavailable);
        } else {
          showError(T.errorGeneric);
        }
      }).catch(function () {
        showError(T.errorGeneric);
      }).then(function () {
        if (timer) clearTimeout(timer);
        setBusy(false);
        resetTurnstile();
      });
    });

    var resetBtn = form.querySelector('[data-form-reset]');
    if (resetBtn) resetBtn.addEventListener('click', function () {
      form.reset();
      attempted = false;
      validatableFields(form).forEach(function (el) { showFieldError(form, el, ''); });
      syncProduct();
      success.hidden = true;
      body.hidden = false;
      resetStart();
      var firstInput = form.querySelector('.input');
      if (firstInput) firstInput.focus();
    });
  }

  if (T) document.querySelectorAll('[data-lead-form]').forEach(initForm);
})();
