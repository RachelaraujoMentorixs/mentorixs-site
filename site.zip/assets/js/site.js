/* Mentorixs — comportamento do site (sem dependências). */
(function () {
  'use strict';
  var doc = document.documentElement;
  doc.classList.remove('no-js');
  doc.classList.add('js');
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function storeSet(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* armazenamento indisponível */ } }

  /* ---------- Idioma: preferência + preservar estado da página ---------- */
  storeSet('mx-lang', doc.lang.indexOf('pt') === 0 ? 'pt' : 'en');
  document.querySelectorAll('[data-lang-link]').forEach(function (a) {
    if (!a.classList.contains('is-current') && (location.search || location.hash)) {
      a.href = a.href.split('#')[0].split('?')[0] + location.search + location.hash;
    }
    a.addEventListener('click', function () { storeSet('mx-lang', a.getAttribute('data-lang-link')); });
  });

  /* ---------- Cabeçalho ---------- */
  var header = document.querySelector('[data-header]');
  if (header) {
    var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 8); };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Menu mobile ---------- */
  var toggle = document.querySelector('[data-menu-toggle]');
  var menu = document.querySelector('[data-menu]');
  if (toggle && menu) {
    var label = toggle.querySelector('[data-menu-label]');
    var setOpen = function (open, restoreFocus) {
      toggle.setAttribute('aria-expanded', String(open));
      menu.hidden = !open;
      document.body.classList.toggle('menu-open', open);
      label.textContent = toggle.getAttribute(open ? 'data-label-close' : 'data-label-open');
      if (open) {
        var first = menu.querySelector('a, button');
        if (first) first.focus();
      } else if (restoreFocus) {
        toggle.focus();
      }
    };
    toggle.addEventListener('click', function () { setOpen(toggle.getAttribute('aria-expanded') !== 'true', true); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) setOpen(false, false); });
    document.addEventListener('keydown', function (e) {
      if (menu.hidden) return;
      if (e.key === 'Escape') { setOpen(false, true); return; }
      if (e.key === 'Tab') {
        var items = [toggle].concat(Array.prototype.slice.call(menu.querySelectorAll('a, button')));
        var i = items.indexOf(document.activeElement);
        if (e.shiftKey && i <= 0) { e.preventDefault(); items[items.length - 1].focus(); }
        else if (!e.shiftKey && i === items.length - 1) { e.preventDefault(); items[0].focus(); }
      }
    });
    window.matchMedia('(min-width: 1140px)').addEventListener('change', function (m) { if (m.matches) setOpen(false, false); });
  }

  /* ---------- Animação de entrada (respeita movimento reduzido) ---------- */
  var revealEls = document.querySelectorAll('[data-reveal]');
  if (!reduceMotion && 'IntersectionObserver' in window && revealEls.length) {
    // Ordem dentro de cada grupo (cards de uma mesma grade entram em sequência).
    revealEls.forEach(function (el) {
      var siblings = Array.prototype.filter.call(el.parentElement.children, function (c) { return c.hasAttribute('data-reveal'); });
      var i = siblings.indexOf(el);
      if (i > 0) el.style.setProperty('--i', String(Math.min(i, 8)));
    });
    var show = function (el) {
      el.classList.add('is-visible');
      // Depois da entrada, remove o atraso para que o hover responda na hora.
      setTimeout(function () { el.style.removeProperty('--i'); }, 1400);
    };
    var vh = window.innerHeight;
    revealEls.forEach(function (el) { if (el.getBoundingClientRect().top < vh * 0.92) show(el); });
    doc.classList.add('reveal-ready');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { show(en.target); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.05 });
    revealEls.forEach(function (el) { if (!el.classList.contains('is-visible')) io.observe(el); });
  }

  /* ---------- Demonstração: pausa as animações quando sai da tela ---------- */
  var concept = document.querySelector('.concept');
  if (concept && !reduceMotion && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { concept.classList.toggle('is-paused', !en.isIntersecting); });
    }).observe(concept);
    document.addEventListener('visibilitychange', function () { concept.classList.toggle('is-paused', document.hidden); });
  }

  /* ---------- Formulários ---------- */
  var i18nEl = document.getElementById('mx-i18n');
  var T = i18nEl ? JSON.parse(i18nEl.textContent) : null;
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function fmt(s, n) { return String(s).replace('{n}', n); }

  function fieldMessage(el) {
    var v = (el.value || '').trim();
    var V = T.validation;
    if (el.required && !v) return el.tagName === 'SELECT' ? V.select : V.required;
    if (!v) return '';
    if (el.type === 'email' && !EMAIL_RE.test(v)) return V.email;
    if (el.type === 'tel') {
      var digits = v.replace(/\D/g, '');
      if (digits.length < 8 || digits.length > 15 || /[^\d\s()+.\-]/.test(v)) return V.phone;
    }
    var min = parseInt(el.getAttribute('data-minlength') || '0', 10);
    if (min && v.length < min) return fmt(V.minLength, min);
    var max = parseInt(el.getAttribute('maxlength') || '0', 10);
    if (max && v.length > max) return fmt(V.maxLength, max);
    return '';
  }

  function showFieldError(form, el, msg) {
    var err = form.querySelector('[data-error-for="' + el.name + '"]');
    if (!err) return;
    if (msg) {
      err.textContent = msg; err.hidden = false; el.setAttribute('aria-invalid', 'true');
    } else {
      err.textContent = ''; err.hidden = true; el.removeAttribute('aria-invalid');
    }
  }

  function validatableFields(form) {
    return Array.prototype.filter.call(form.querySelectorAll('input.input, select.input, textarea.input'), function (el) {
      return !el.closest('[hidden]');
    });
  }

  function validate(form) {
    var invalid = [];
    validatableFields(form).forEach(function (el) {
      var msg = fieldMessage(el);
      showFieldError(form, el, msg);
      if (msg) invalid.push(el);
    });
    return invalid;
  }

  function serialize(form) {
    var data = {};
    var fd = new FormData(form);
    fd.forEach(function (value, key) {
      if (key === 'users') { (data.users = data.users || []).push(value); return; }
      data[key] = typeof value === 'string' ? value.trim() : value;
    });
    return data;
  }

  function initForm(form) {
    var endpoint = form.getAttribute('data-endpoint');
    var body = form.querySelector('[data-form-body]');
    var summary = form.querySelector('[data-form-summary]');
    var errorBox = form.querySelector('[data-form-error]');
    var errorText = form.querySelector('[data-form-error-text]');
    var success = form.querySelector('[data-form-success]');
    var submitBtn = form.querySelector('[data-submit]');
    var submitLabel = form.querySelector('[data-submit-label]');
    var started = form.querySelector('[data-started-at]');
    var attempted = false;
    var busy = false;

    var resetStart = function () { if (started) started.value = String(Date.now()); };
    resetStart();

    // Campo "Produto de interesse": visível apenas para "Sistema por assinatura" ou quando já vem preenchido pela URL.
    var interest = form.querySelector('select[name="interest"]');
    var productWrap = form.querySelector('[data-product-field]');
    var productSel = productWrap ? productWrap.querySelector('select') : null;
    var syncProduct = function () {
      if (!productWrap) return;
      var show = interest.value === 'subscription' || (productSel.value && productSel.value !== '');
      productWrap.hidden = !show;
    };
    if (interest && productWrap) {
      var params = new URLSearchParams(location.search);
      var qi = params.get('interest');
      var qp = params.get('product');
      if (qi && interest.querySelector('option[value="' + CSS.escape(qi) + '"]')) interest.value = qi;
      if (qp && productSel.querySelector('option[value="' + CSS.escape(qp) + '"]')) productSel.value = qp;
      interest.addEventListener('change', function () {
        if (interest.value !== 'subscription') productSel.value = '';
        syncProduct();
      });
      syncProduct();
    }

    form.addEventListener('input', function (e) {
      if (attempted && e.target.classList && e.target.classList.contains('input')) showFieldError(form, e.target, fieldMessage(e.target));
    });
    form.addEventListener('focusout', function (e) {
      var el = e.target;
      if (el.classList && el.classList.contains('input') && (attempted || el.value)) showFieldError(form, el, fieldMessage(el));
    });

    var setBusy = function (state) {
      busy = state;
      form.setAttribute('aria-busy', String(state));
      submitBtn.disabled = state;
      submitLabel.textContent = submitLabel.getAttribute(state ? 'data-label-busy' : 'data-label-idle');
    };

    var showError = function (msg) {
      errorText.textContent = msg + (T.errorAlt ? ' ' + T.errorAlt : '');
      errorBox.hidden = false;
      errorBox.focus();
    };

    var resetTurnstile = function () {
      if (window.turnstile && form.querySelector('.cf-turnstile')) { try { window.turnstile.reset(form.querySelector('.cf-turnstile')); } catch (e) {} }
    };

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (busy) return;
      attempted = true;
      errorBox.hidden = true;
      var invalid = validate(form);
      if (invalid.length) {
        summary.textContent = invalid.length === 1 ? T.errorSummaryOne : fmt(T.errorSummaryMany, invalid.length);
        summary.hidden = false;
        invalid[0].focus();
        return;
      }
      summary.hidden = true;

      var data = serialize(form);
      if (form.querySelector('.cf-turnstile') && !data['cf-turnstile-response']) { showError(T.errorCaptcha); return; }
      if (!endpoint) {
        if (window.console) console.warn('[Mentorixs] Formulário sem endpoint configurado (content/site.json → forms.endpoint).');
        showError(T.errorUnavailable);
        return;
      }

      setBusy(true);
      var controller = 'AbortController' in window ? new AbortController() : null;
      var timer = controller ? setTimeout(function () { controller.abort(); }, 20000) : null;

      fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(data),
        signal: controller ? controller.signal : undefined,
        credentials: 'same-origin'
      }).then(function (res) {
        return res.json().catch(function () { return {}; }).then(function (json) { return { res: res, json: json }; });
      }).then(function (r) {
        // A confirmação só aparece quando o servidor informa que a solicitação foi recebida.
        if (r.res.ok && r.json && r.json.ok === true) {
          body.hidden = true;
          success.hidden = false;
          success.focus();
          return;
        }
        var err = r.json && r.json.error;
        if (err === 'validation' && r.json.fields) {
          var first = null;
          var count = 0;
          Object.keys(r.json.fields).forEach(function (name) {
            var info = r.json.fields[name] || {};
            var el = form.querySelector('[name="' + name + '"].input');
            var msg = T.validation[info.code] ? fmt(T.validation[info.code], info.n || '') : T.validation.required;
            if (el) { showFieldError(form, el, msg); first = first || el; count++; }
          });
          if (!count) { showError(T.errorGeneric); return; }
          summary.textContent = count === 1 ? T.errorSummaryOne : fmt(T.errorSummaryMany, count);
          summary.hidden = false;
          if (first) first.focus();
        } else if (err === 'spam') {
          showError(T.errorSpam);
        } else if (err === 'captcha') {
          showError(T.errorCaptcha);
        } else if (err === 'unavailable' || r.res.status === 503 || r.res.status === 404) {
          showError(T.errorUnavailable);
        } else {
          showError(T.errorGeneric);
        }
      }).catch(function () {
        showError(T.errorGeneric);
      }).then(function () {
        if (timer) clearTimeout(timer);
        setBusy(false);
        resetTurnstile();
      });
    });

    var resetBtn = form.querySelector('[data-form-reset]');
    if (resetBtn) resetBtn.addEventListener('click', function () {
      form.reset();
      attempted = false;
      validatableFields(form).forEach(function (el) { showFieldError(form, el, ''); });
      syncProduct();
      success.hidden = true;
      body.hidden = false;
      resetStart();
      var firstInput = form.querySelector('.input');
      if (firstInput) firstInput.focus();
    });
  }

  if (T) document.querySelectorAll('[data-lead-form]').forEach(initForm);
})();

/* ---------- Dados do site vindos do Mentorixs Hub (Hub › Site Mentorixs) ---------- */
(function () {
  'use strict';
  if (!window.fetch) return;
  var ORIG = { wa: '18155752585', waTxt: '+1 (815) 575-2585', email: 'contato@mentorixs.com.br', insta: 'mentorixs_' };
  var en = (document.documentElement.lang || '').indexOf('en') === 0;
  function trocaTexto(de, para) {
    if (!para || de === para) return;
    var w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null), nd;
    while ((nd = w.nextNode())) if (nd.nodeValue.indexOf(de) >= 0) nd.nodeValue = nd.nodeValue.split(de).join(para);
    document.querySelectorAll('[aria-label],[title]').forEach(function (el) {
      ['aria-label', 'title'].forEach(function (a) { var v = el.getAttribute(a); if (v && v.indexOf(de) >= 0) el.setAttribute(a, v.split(de).join(para)); });
    });
  }
  function aplicar(c) {
    if (!c || typeof c !== 'object') return;
    var wa = String(c.whatsapp || '').replace(/\D/g, '');
    var msg = en ? c.whatsapp_mensagem_en : c.whatsapp_mensagem_pt;
    if (wa) document.querySelectorAll('a[href^="https://wa.me/"]').forEach(function (a) {
      var u = new URL(a.href); var txt = u.searchParams.get('text') || msg || ''; // mensagem própria de cada página tem prioridade
      a.href = 'https://wa.me/' + wa + (txt ? '?text=' + encodeURIComponent(txt) : '');
    });
    if (c.whatsapp_exibicao) trocaTexto(ORIG.waTxt, c.whatsapp_exibicao);
    if (c.email && /^\S+@\S+\.\S+$/.test(c.email)) {
      document.querySelectorAll('a[href^="mailto:"]').forEach(function (a) { a.href = a.href.split(ORIG.email).join(c.email); });
      trocaTexto(ORIG.email, c.email);
    }
    var ig = String(c.instagram || '').replace(/[^A-Za-z0-9._]/g, '');
    if (ig && ig !== ORIG.insta) {
      document.querySelectorAll('a[href*="instagram.com/"]').forEach(function (a) { a.href = 'https://www.instagram.com/' + ig + '/'; });
      trocaTexto('@' + ORIG.insta, '@' + ig);
    }
    var aviso = en ? (c.aviso_en || c.aviso_pt) : c.aviso_pt;
    if (c.aviso_ativo && aviso && !document.querySelector('[data-mx-aviso]')) {
      var bar = document.createElement(/^https:\/\//.test(c.aviso_link || '') ? 'a' : 'div');
      bar.setAttribute('data-mx-aviso', '');
      if (bar.tagName === 'A') { bar.href = c.aviso_link; bar.rel = 'noopener'; }
      bar.textContent = aviso;
      bar.style.cssText = 'display:block;padding:9px 16px;text-align:center;font-size:14px;font-weight:600;line-height:1.4;color:#fff;background:#392963;text-decoration:none';
      document.body.insertBefore(bar, document.body.firstChild);
    }
  }
  var ctl = 'AbortController' in window ? new AbortController() : null;
  if (ctl) setTimeout(function () { ctl.abort(); }, 6000);
  fetch('https://rvwbameqatclfnaesqwe.supabase.co/rest/v1/rpc/site_publico', {
    method: 'POST', body: '{}', signal: ctl ? ctl.signal : undefined,
    headers: { apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2d2JhbWVxYXRjbGZuYWVzcXdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ0MTI2MzUsImV4cCI6MjEwOTk4ODYzNX0.4yRqi1gFAYJSA-YJtwPPlt-PhPwGi8MbFpsnxLDg3SM', Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2d2JhbWVxYXRjbGZuYWVzcXdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ0MTI2MzUsImV4cCI6MjEwOTk4ODYzNX0.4yRqi1gFAYJSA-YJtwPPlt-PhPwGi8MbFpsnxLDg3SM', 'Content-Type': 'application/json' }
  }).then(function (r) { return r.ok ? r.json() : null; }).then(function (c) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { aplicar(c); }); else aplicar(c);
  }).catch(function () { /* sem conexão com o Hub: o site segue com os dados de sempre */ });
})();

/* ---------- Fase 2: prova social vinda do Hub (só aparece o que foi preenchido e autorizado) ---------- */
(function () {
  'use strict';
  var en = (document.documentElement.lang || '').indexOf('en') === 0;
  var T = en ? {
    caseEb: 'Case', caseH: 'A real system, in operation', antes: 'The problem (before)', feito: 'What was built', depois: 'The result (after)',
    depEb: 'Testimonials', depH: 'What our clients say', numEb: 'In numbers', numH: 'Mentorixs in numbers',
    fundEb: 'Founding clients', fundH: 'Become a founding client', fundTxt: 'Recent launch. Each founding client gets direct support from the team that built the system, in exchange for a testimonial and permission to mention the company.',
    vagas: ' spots available', vidEb: 'Video', vidH: 'See it in 60 seconds', vidPlay: 'Play the video',
    nome: 'Name', empresa: 'Company', email: 'E-mail', whats: 'WhatsApp', msg: 'Tell us briefly about your operation (optional)', consent: 'I agree that Mentorixs may contact me about this application, according to the privacy policy.',
    enviar: 'Apply', enviando: 'Sending…', ok: 'Application received. We will contact you soon.', err: 'Could not send now. Please try again or reach us on WhatsApp.', obrig: 'Fill in name, e-mail and accept the consent.'
  } : {
    caseEb: 'Case', caseH: 'Um sistema real, em operação', antes: 'O problema (antes)', feito: 'O que foi construído', depois: 'O resultado (depois)',
    depEb: 'Depoimentos', depH: 'O que dizem os clientes', numEb: 'Em números', numH: 'A Mentorixs em números',
    fundEb: 'Clientes-fundadores', fundH: 'Seja um cliente-fundador', fundTxt: 'Lançamento recente. Cada cliente-fundador recebe acompanhamento direto do time que desenvolveu o sistema, em troca de depoimento e autorização para citar sua empresa.',
    vagas: ' vagas disponíveis', vidEb: 'Vídeo', vidH: 'Veja em 60 segundos', vidPlay: 'Assistir ao vídeo',
    nome: 'Nome', empresa: 'Empresa', email: 'E-mail', whats: 'WhatsApp', msg: 'Conte rapidamente sobre a sua operação (opcional)', consent: 'Concordo que a Mentorixs entre em contato sobre esta candidatura, conforme a política de privacidade.',
    enviar: 'Quero me candidatar', enviando: 'Enviando…', ok: 'Candidatura recebida. Entraremos em contato em breve.', err: 'Não foi possível enviar agora. Tente de novo ou fale pelo WhatsApp.', obrig: 'Preencha nome, e-mail e aceite o consentimento.'
  };
  function el(tag, cls, txt) { var e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = String(txt); return e; }
  function https(u) { u = String(u || ''); return /^https:\/\/[^\s"'<>]+$/.test(u) ? u : ''; }
  function txt(v) { return String(v || '').trim(); }
  function secao(slot, eb, h, sub, tint) {
    var s = el('section', 'mx-sec' + (tint ? ' mx-sec-tint' : '')); var c = el('div', 'container');
    c.appendChild(el('p', 'mx-eb', eb)); var hh = el('h2', 'mx-h', h); c.appendChild(hh); if (sub) c.appendChild(el('p', 'mx-sub', sub));
    s.appendChild(c); slot.appendChild(s); slot.hidden = false; return c;
  }
  function render(cfg) {
    var p = cfg && cfg.prova; if (!p || typeof p !== 'object') return;
    document.querySelectorAll('[data-mx-slot]').forEach(function (slot) {
      var tipo = slot.getAttribute('data-mx-slot'), prod = slot.getAttribute('data-produto');
      if (tipo === 'case') {
        var k = p['case'] || {}; if (!k.ativo || !k.autorizado || !txt(k.problema) || !txt(k.construido) || !txt(k.resultado)) return;
        var c = secao(slot, T.caseEb, T.caseH, txt(k.descricao_cliente), true); var g = el('div', 'mx-case');
        [[T.antes, k.problema], [T.feito, k.construido], [T.depois, k.resultado]].forEach(function (x) { var d = el('div', 'mx-card'); d.appendChild(el('h3', '', x[0])); d.appendChild(el('p', '', txt(x[1]))); g.appendChild(d); });
        c.appendChild(g);
        if (txt(k.depoimento)) { var q = el('blockquote', 'mx-quote', '“' + txt(k.depoimento) + '”'); if (txt(k.autor)) q.appendChild(el('footer', '', '— ' + txt(k.autor) + (txt(k.cargo) ? ', ' + txt(k.cargo) : ''))); c.appendChild(q); }
      } else if (tipo === 'depoimentos') {
        var lista = (p.depoimentos || []).filter(function (d) { return d && d.autorizado && txt(d.texto) && txt(d.nome); }); if (!lista.length) return;
        var c2 = secao(slot, T.depEb, T.depH, '', false); var g2 = el('div', 'mx-dep');
        lista.slice(0, 6).forEach(function (d) { var card = el('figure', 'mx-card'); card.style.margin = '0'; card.appendChild(el('p', '', '“' + txt(d.texto) + '”'));
          var pe = el('figcaption', 'mx-pessoa'); var foto = https(d.foto); if (foto) { var im = el('img'); im.src = foto; im.alt = ''; im.loading = 'lazy'; im.width = 44; im.height = 44; pe.appendChild(im); }
          var w = el('div'); w.appendChild(el('b', '', txt(d.nome))); w.appendChild(el('span', '', [txt(d.cargo), txt(d.empresa)].filter(Boolean).join(' · '))); pe.appendChild(w); card.appendChild(pe); g2.appendChild(card); });
        c2.appendChild(g2);
      } else if (tipo === 'logos') {
        var ls = (p.logos || []).filter(function (l) { return l && l.autorizado && https(l.imagem); }); if (!ls.length) return;
        var s = el('section', 'mx-sec-tint'); var c3 = el('div', 'container mx-logos'); c3.setAttribute('aria-label', en ? 'Clients' : 'Clientes');
        ls.slice(0, 12).forEach(function (l) { var im = el('img'); im.src = https(l.imagem); im.alt = txt(l.nome); im.loading = 'lazy'; c3.appendChild(im); });
        s.appendChild(c3); slot.appendChild(s); slot.hidden = false;
      } else if (tipo === 'numeros') {
        var ns = (p.numeros || []).filter(function (x) { return x && txt(x.valor) && txt(en ? (x.rotulo_en || x.rotulo_pt) : x.rotulo_pt); }); if (!ns.length) return;
        var c4 = secao(slot, T.numEb, T.numH, '', false); var g4 = el('div', 'mx-num');
        ns.slice(0, 4).forEach(function (x) { var d = el('div', 'mx-card'); d.appendChild(el('strong', '', txt(x.valor))); d.appendChild(el('p', '', txt(en ? (x.rotulo_en || x.rotulo_pt) : x.rotulo_pt))); g4.appendChild(d); });
        c4.appendChild(g4);
      } else if (tipo === 'fundadores') {
        var f = p.fundadores || {}; var ben = txt(en ? (f.beneficio_en || f.beneficio_pt) : f.beneficio_pt); if (!f.ativo || !ben || !(Number(f.vagas) > 0)) return;
        var s5 = el('section', 'mx-sec'); var c5 = el('div', 'container mx-fund'); var box = el('div', 'mx-fund-box');
        box.appendChild(el('p', 'mx-eb', T.fundEb)); box.appendChild(el('h2', 'mx-h', T.fundH)); box.appendChild(el('p', '', ben)); box.appendChild(el('p', '', T.fundTxt));
        box.appendChild(el('span', 'mx-fund-vagas', String(Number(f.vagas)) + T.vagas)); c5.appendChild(box);
        c5.appendChild(formFundador(prod)); s5.appendChild(c5); slot.appendChild(s5); slot.hidden = false;
      } else if (tipo === 'video') {
        var vs = p.videos || {}; var url = https(vs.ehs || vs.business || vs.corporate); var id = null, tipoV = null, m;
        if ((m = url.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/))) { id = m[1]; tipoV = 'yt'; }
        else if ((m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/))) { id = m[1]; tipoV = 'vm'; }
        if (!id) return;
        var c6 = secao(slot, T.vidEb, T.vidH, '', true); var v = el('div', 'mx-video'); var b = el('button'); b.type = 'button'; b.setAttribute('aria-label', T.vidPlay);
        if (tipoV === 'yt') b.style.backgroundImage = 'url(https://i.ytimg.com/vi/' + id + '/hqdefault.jpg)';
        b.addEventListener('click', function () { var f = document.createElement('iframe'); f.title = T.vidH; f.allow = 'autoplay; fullscreen; picture-in-picture'; f.allowFullscreen = true;
          f.src = tipoV === 'yt' ? 'https://www.youtube-nocookie.com/embed/' + id + '?autoplay=1&rel=0' : 'https://player.vimeo.com/video/' + id + '?autoplay=1'; v.replaceChildren(f); });
        v.appendChild(b); c6.appendChild(v);
      }
    });
  }
  function formFundador(prod) {
    var f = el('form', 'mx-card mx-form'); f.noValidate = true; var inicio = Date.now();
    function campo(nome, rot, tipo, req) { var l = el('label', '', rot + (req ? ' *' : '')); var i = el(tipo === 'textarea' ? 'textarea' : 'input'); if (tipo !== 'textarea') i.type = tipo; i.name = nome; if (tipo === 'textarea') i.rows = 3; if (nome === 'email') i.autocomplete = 'email'; if (nome === 'name') i.autocomplete = 'name'; if (nome === 'phone') i.autocomplete = 'tel'; l.appendChild(i); f.appendChild(l); return i; }
    var nome = campo('name', T.nome, 'text', true), emp = campo('company', T.empresa, 'text', false), email = campo('email', T.email, 'email', true), tel = campo('phone', T.whats, 'tel', false), msg = campo('message', T.msg, 'textarea', false);
    var hp = el('input', 'mx-hp'); hp.name = 'website'; hp.tabIndex = -1; hp.autocomplete = 'off'; hp.setAttribute('aria-hidden', 'true'); f.appendChild(hp);
    var ck = el('label', 'mx-ck'); var cb = el('input'); cb.type = 'checkbox'; ck.appendChild(cb); ck.appendChild(el('span', '', T.consent)); f.appendChild(ck);
    var bt = el('button', '', T.enviar); bt.type = 'submit'; f.appendChild(bt); var out = el('p', 'mx-form-msg'); out.setAttribute('role', 'status'); f.appendChild(out);
    f.addEventListener('submit', function (e) {
      e.preventDefault(); out.className = 'mx-form-msg';
      if (!txt(nome.value) || !/^\S+@\S+\.\S+$/.test(email.value) || !cb.checked) { out.className = 'mx-form-msg err'; out.textContent = T.obrig; return; }
      bt.disabled = true; bt.textContent = T.enviando;
      fetch('https://rvwbameqatclfnaesqwe.supabase.co/functions/v1/contato-ehs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ formType: 'cliente-fundador', name: nome.value, company: emp.value, email: email.value, phone: tel.value, message: msg.value, product: 'Mentorixs EHS', interest: 'cliente-fundador', consent: true, website: hp.value, lang: en ? 'en' : 'pt', page: location.pathname, startedAt: String(inicio) }) })
        .then(function (r) { return r.json().then(function (j) { return r.ok && j && j.ok; }); })
        .then(function (ok) { if (ok) { f.replaceChildren(el('p', 'mx-form-msg ok', T.ok)); } else throw 0; })
        .catch(function () { out.className = 'mx-form-msg err'; out.textContent = T.err; bt.disabled = false; bt.textContent = T.enviar; });
    });
    return f;
  }
  if (!window.fetch || !document.querySelector('[data-mx-slot]')) return;
  window.__mxSite = window.__mxSite || fetch('https://rvwbameqatclfnaesqwe.supabase.co/rest/v1/rpc/site_publico', { method: 'POST', body: '{}', headers: { apikey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2d2JhbWVxYXRjbGZuYWVzcXdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ0MTI2MzUsImV4cCI6MjEwOTk4ODYzNX0.4yRqi1gFAYJSA-YJtwPPlt-PhPwGi8MbFpsnxLDg3SM', Authorization: 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ2d2JhbWVxYXRjbGZuYWVzcXdlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQ0MTI2MzUsImV4cCI6MjEwOTk4ODYzNX0.4yRqi1gFAYJSA-YJtwPPlt-PhPwGi8MbFpsnxLDg3SM', 'Content-Type': 'application/json' } }).then(function (r) { return r.ok ? r.json() : null; });
  window.__mxSite.then(function (c) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { render(c); }); else render(c); }).catch(function () {});
})();

/* ---------- Fase 3: formulário "Monte o seu plano" (pede proposta; nenhum preço é calculado no site) ---------- */
(function () {
  'use strict';
  var f = document.querySelector('form[data-mx-proposta]'); if (!f || !window.fetch) return;
  var en = (document.documentElement.lang || '').indexOf('en') === 0, inicio = Date.now();
  var M = en ? { obrig: 'Fill in name, e-mail and accept the consent.', env: 'Sending…', ok: 'Request received. Mentorixs will send your proposal soon.', err: 'Could not send now. Please try again or reach us on WhatsApp.' }
             : { obrig: 'Preencha nome, e-mail e aceite o consentimento.', env: 'Enviando…', ok: 'Pedido recebido. A Mentorixs vai enviar a sua proposta em breve.', err: 'Não foi possível enviar agora. Tente de novo ou fale pelo WhatsApp.' };
  var out = f.querySelector('.mx-form-msg'), bt = f.querySelector('button[type=submit]'), rot = bt.textContent;
  f.addEventListener('submit', function (e) {
    e.preventDefault(); var v = function (n) { var x = f.elements[n]; return x ? String(x.value || '').trim() : ''; };
    if (!v('name') || !/^\S+@\S+\.\S+$/.test(v('email')) || !f.elements.consent.checked) { out.className = 'mx-form-msg err'; out.textContent = M.obrig; return; }
    var mods = Array.prototype.map.call(f.querySelectorAll('input[name=modulos]:checked'), function (c) { return c.value; });
    var msg = (en ? 'Companies/IDs served: ' : 'Empresas/CNPJs atendidos: ') + (v('empresas') || '-') + ' · ' + (en ? 'Users: ' : 'Usuários: ') + (v('usuarios') || '-') + '\n' + (en ? 'Modules: ' : 'Módulos: ') + (mods.join(', ') || '-');
    bt.disabled = true; bt.textContent = M.env; out.className = 'mx-form-msg'; out.textContent = '';
    fetch('https://rvwbameqatclfnaesqwe.supabase.co/functions/v1/contato-ehs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ formType: 'proposta-ehs', name: v('name'), company: v('company'), email: v('email'), phone: v('phone'), message: msg, product: 'Mentorixs EHS', interest: 'proposta-plano', consent: true, website: v('website'), lang: en ? 'en' : 'pt', page: location.pathname, startedAt: String(inicio) }) })
      .then(function (r) { return r.json().then(function (j) { return r.ok && j && j.ok; }); })
      .then(function (ok) { if (!ok) throw 0; f.innerHTML = ''; var p = document.createElement('p'); p.className = 'mx-form-msg ok'; p.textContent = M.ok; f.appendChild(p); })
      .catch(function () { out.className = 'mx-form-msg err'; out.textContent = M.err; bt.disabled = false; bt.textContent = rot; });
  });
})();

/* ---------- Faixa de prova social: entra com movimento e conta até o número ---------- */
(function () {
  'use strict';
  var fs = document.querySelectorAll('.mx-pv'); if (!fs.length) return;
  var calmo = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (calmo || !('IntersectionObserver' in window)) return;
  function conta(el) {
    var alvo = el.getAttribute('data-mx-conta-ate') || el.textContent, m = alvo.match(/[\d.,]+/); if (!m) return;
    var n = parseInt(m[0].replace(/[.,]/g, ''), 10), sep = m[0].indexOf(',') >= 0 ? ',' : '.', ini = performance.now(), dur = 1600;
    function fmt(v) { return String(v).replace(/\B(?=(\d{3})+(?!\d))/g, sep); }
    function passo(t) { var p = Math.min(1, (t - ini) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = alvo.replace(m[0], fmt(Math.round(n * e))); if (p < 1) requestAnimationFrame(passo); else el.textContent = alvo; }
    requestAnimationFrame(passo);
  }
  var io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (!e.isIntersecting) return;
    e.target.classList.add('mx-vis'); var n = e.target.querySelector('[data-mx-conta-ate]'); if (n) conta(n); io.unobserve(e.target); }); }, { threshold: .35 });
  fs.forEach(function (f) { f.classList.add('mx-anim'); io.observe(f); });
})();

/* ---------- Painel "Faça a conta": vidas ativas × CNPJ ativo (só calcula no navegador) ---------- */
(function () {
  'use strict';
  var c = document.querySelector('[data-mx-conta]'); if (!c) return;
  var preco = parseFloat(c.getAttribute('data-preco')) || 0;
  var en = (document.documentElement.lang || '').indexOf('en') === 0;
  var fmt = new Intl.NumberFormat(en ? 'en-US' : 'pt-BR', { maximumFractionDigits: 0 });
  var fmt2 = new Intl.NumberFormat(en ? 'en-US' : 'pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  var R = function (v) { return 'R$ ' + fmt.format(Math.round(v)); };
  var q = function (s) { return c.querySelector(s); };
  var vid = q('#fc-vidas'), val = q('#fc-valor'), cnp = q('#fc-cnpjs'), eco = q('.mx-fc-eco'), nota = q('.mx-fc-nota');
  function pinta(i) { var p = (i.value - i.min) / (i.max - i.min) * 100; i.style.setProperty('--p', p + '%');
    var o = c.querySelector('[data-saida="' + i.id + '"]'); var pre = i.getAttribute('data-pre') || '';
    o.textContent = pre + (i.id === 'fc-valor' ? fmt2.format(+i.value) : fmt.format(+i.value)); }
  function calc() {
    [vid, val, cnp].forEach(pinta);
    var hoje = (+vid.value) * (+val.value) * 12, mx = preco * (+cnp.value) * 12, d = hoje - mx;
    q('[data-r="hoje"]').textContent = R(hoje); q('[data-r="mx"]').textContent = R(mx);
    if (d > 0) { eco.classList.remove('neg'); q('[data-r="eco"]').textContent = R(d); q('[data-r="eco-rot"]').hidden = false; nota.textContent = nota.getAttribute('data-nota'); }
    else { eco.classList.add('neg'); q('[data-r="eco"]').textContent = nota.getAttribute('data-nota-neg'); q('[data-r="eco-rot"]').hidden = true; nota.textContent = nota.getAttribute('data-nota'); }
  }
  [vid, val, cnp].forEach(function (i) { i.addEventListener('input', calc); });
  calc();
  var cta = q('.mx-fc-cta'), form = document.querySelector('form[data-mx-proposta]');
  if (cta && form) cta.addEventListener('click', function () {
    var e = form.elements; if (e.empresas && !e.empresas.value) e.empresas.value = cnp.value;
  });
})();
