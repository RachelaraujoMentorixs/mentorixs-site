// Página raiz: encaminha para o idioma salvo ou do navegador.
(function () {
  var s = document.currentScript;
  var saved = null;
  try { saved = localStorage.getItem('mx-lang'); } catch (e) {}
  var lang = saved;
  if (lang !== 'pt' && lang !== 'en') {
    var list = navigator.languages || [navigator.language || ''];
    lang = s.getAttribute('data-default') || 'pt';
    for (var i = 0; i < list.length; i++) {
      var l = String(list[i]).toLowerCase();
      if (l.indexOf('pt') === 0) { lang = 'pt'; break; }
      if (l.indexOf('en') === 0) { lang = 'en'; break; }
    }
  }
  location.replace(s.getAttribute('data-' + lang) + location.search + location.hash);
})();
